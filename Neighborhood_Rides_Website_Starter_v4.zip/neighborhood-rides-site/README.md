# Neighborhood Rides Inc. — Website

A minimal Next.js + Tailwind site. Includes a logo, services, how-it-works, booking (mailto), and contact.

## Quick start
1) Install Node.js 18+
2) `npm install`
3) `npm run dev` — open http://localhost:3000

## Customize
- Replace `/public/logo.png` with your final logo.
- Update phone/email in `app/page.tsx` (search `(555)` and `rides@`).
- Deploy to Vercel or Netlify.

## Notes
- Booking uses `mailto:` to open the user’s email client with a prefilled request.

## Configuration
Edit `app/config.ts` to set:
- BUSINESS_PHONE
- DISPATCH_EMAIL
- BILLING_EMAIL
- HOURS_LONG / HOURS_SHORT
- CALENDLY_URL (for the embedded scheduler on /schedule)

## Routes
- `/` — Landing + booking form (mailto)
- `/schedule` — Embedded Calendly (set CALENDLY_URL)
- `/invoice` — Partner invoice request (mailto to BILLING_EMAIL)

## Deploy to Vercel

**Option A — Drag & Drop (no Git needed)**
1. Go to https://vercel.com/new
2. Click **Add New… → Project** (or **Import**).
3. Choose **Import a project** and click **Upload** → select the **neighborhood-rides-site** folder from this ZIP.
4. Accept defaults and click **Deploy**. In ~1 minute you'll get a live URL.

**Option B — One‑Click “Deploy with Vercel” Button (requires GitHub)**
1. Create a new **GitHub repo** and upload the contents of the **neighborhood-rides-site** folder.
2. Click this button and select your repo when prompted:

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=<YOUR_GITHUB_REPO_URL>)

Replace `<YOUR_GITHUB_REPO_URL>` with your repo’s HTTPS URL (e.g., `https://github.com/yourname/neighborhood-rides-site`).
