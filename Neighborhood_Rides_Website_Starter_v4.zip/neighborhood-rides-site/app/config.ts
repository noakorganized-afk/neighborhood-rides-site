// Update these values with your real info
export const BUSINESS_PHONE = "6127042972"; // <-- replace with your phone number
export const DISPATCH_EMAIL = "rides@neighborhoodrides.org";
export const BILLING_EMAIL = "billing@neighborhoodrides.org";
export const HOURS_LONG = "Monday – Saturday: 7:00 AM – 10:00 PM (Closed Sunday)";
export const HOURS_SHORT = "Mon–Sat 7am–10pm (Sun closed)";
export const SERVICE_AREA = "Twin Cities Metro";
// Optional: Calendly or other scheduler URL
export const CALENDLY_URL = "https://calendly.com/your-handle/ride-request"; // replace with your link
