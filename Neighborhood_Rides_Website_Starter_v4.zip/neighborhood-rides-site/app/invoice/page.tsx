"use client";
import React, { useState } from "react";
import { BILLING_EMAIL } from "../config";

export default function InvoicePage() {
  const [org, setOrg] = useState("");
  const [contact, setContact] = useState("");
  const [email, setEmail] = useState("");
  const [rides, setRides] = useState("");
  const [po, setPo] = useState("");

  const submit = () => {
    const body = encodeURIComponent(
      `Invoice request\n\nOrganization: ${org}\nContact: ${contact}\nEmail: ${email}\nRide dates/details: ${rides}\nPO/Case #: ${po}`
    );
    window.location.href = `mailto:${BILLING_EMAIL}?subject=Invoice%20Request&body=${body}`;
  };

  return (
    <main className="min-h-screen py-16 bg-white">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-3xl font-bold tracking-tight">Partner Invoice Request</h1>
        <p className="mt-2 text-slate-600">Submit details below; we’ll follow up with an invoice and payment link.</p>
        <div className="mt-6 grid gap-4">
          <input className="border rounded-md p-2" placeholder="Organization" value={org} onChange={e=>setOrg(e.target.value)} />
          <input className="border rounded-md p-2" placeholder="Contact name" value={contact} onChange={e=>setContact(e.target.value)} />
          <input className="border rounded-md p-2" placeholder="Contact email" value={email} onChange={e=>setEmail(e.target.value)} />
          <textarea className="border rounded-md p-2" placeholder="Ride dates and details" value={rides} onChange={e=>setRides(e.target.value)} />
          <input className="border rounded-md p-2" placeholder="PO/Case # (optional)" value={po} onChange={e=>setPo(e.target.value)} />
          <div><button onClick={submit} className="px-5 py-2 rounded-2xl bg-slate-900 text-white">Request Invoice</button></div>
        </div>
      </div>
    </main>
  );
}
