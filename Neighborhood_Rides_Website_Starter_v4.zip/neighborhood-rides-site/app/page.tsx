"use client";
import React, { useState } from "react";
  import { BUSINESS_PHONE, DISPATCH_EMAIL, HOURS_LONG, HOURS_SHORT } from "./config";

const Stat = ({ label, value }: { label: string; value: string }) => (
  <div className="flex flex-col items-center p-4">
    <div className="text-3xl font-bold">{value}</div>
    <div className="text-sm text-slate-500">{label}</div>
  </div>
);

export default function Page() {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [pickup, setPickup] = useState("");
  const [dropoff, setDropoff] = useState("");
  const [date, setDate] = useState("");
  const [notes, setNotes] = useState("");

  const handleBooking = () => {
    const body = encodeURIComponent(
      `Ride request for Neighborhood Rides Inc.%0D%0A%0D%0AName: ${name}\nPhone: ${phone}\nPickup: ${pickup}\nDropoff: ${dropoff}\nDate/Time: ${date}\nNotes: ${notes}`
    );
    window.location.href = `mailto:{DISPATCH_EMAIL}?subject=Ride%20Request&body=${body}`;
  };

  return (
    <main className="min-h-screen">
      <header className="sticky top-0 bg-white/80 backdrop-blur border-b">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/logo.png" alt="Neighborhood Rides Inc. logo" className="w-10 h-10 rounded" />
            <div className="font-bold tracking-tight">Neighborhood Rides Inc.</div>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#services" className="hover:underline">Services</a>
            <a href="#how" className="hover:underline">How it Works</a>
            <a href="#about" className="hover:underline">About</a>
            <a href="#booking" className="hover:underline">Book</a>
            <a href="#contact" className="hover:underline">Contact</a>
          </nav>
        </div>
      </header>

      <section className="bg-slate-50">
        <div className="max-w-6xl mx-auto px-4 py-16 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <span className="inline-block text-xs px-3 py-1 rounded-full border">Driving Recovery & Opportunity</span>
            <h1 className="mt-4 text-4xl md:text-5xl font-extrabold tracking-tight leading-tight">
              Safe, reliable rides for treatment, court, and new beginnings.
            </h1>
            <p className="mt-4 text-lg text-slate-600">
              We partner with treatment providers, reentry programs, and courts to make sure people get where they need to go—
              with dignity, on time, every time.
            </p>
            <div className="mt-6 flex gap-3">
              <a href="#booking" className="inline-flex items-center justify-center px-5 py-3 rounded-2xl bg-slate-900 text-white">
                Schedule a Ride
              </a>
              <a href={`tel:${BUSINESS_PHONE}`} className="inline-flex items-center gap-2 text-sm font-semibold underline">
                Call Dispatch
              </a>
            </div>

            <div className="mt-8 grid grid-cols-3 gap-4">
              <Stat label="On-time rate" value="98%" />
              <Stat label="Avg. ride rating" value="4.9/5" />
              <Stat label="Service days" value="7/week" />
            </div>
          </div>
          <div className="flex items-center justify-center">
            <div className="rounded-2xl shadow p-6 bg-white max-w-md">
              <h3 className="font-semibold text-lg">Why riders choose us</h3>
              <ul className="mt-4 space-y-3 text-sm text-slate-700">
                <li>• Purpose-built service for treatment, court, and essential appointments</li>
                <li>• Insured vehicles, vetted drivers, clear safety policies</li>
                <li>• Pre-book or same-day (as available); confirmations & reminders</li>
                <li>• Community impact: fewer missed appointments, better outcomes</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section id="services" className="py-16 border-t bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold tracking-tight">Services</h2>
          <p className="mt-2 text-slate-600 max-w-3xl">
            Respectful transportation for individuals in recovery and those navigating the justice system.
          </p>
          <div className="mt-8 grid md:grid-cols-3 gap-6">
            <div className="rounded-2xl border p-6"><h3 className="font-semibold">Treatment & Recovery</h3><p className="text-sm text-slate-700 mt-2">Routes to detox, inpatient/outpatient programs, therapy, and support groups.</p></div>
            <div className="rounded-2xl border p-6"><h3 className="font-semibold">Court & Probation</h3><p className="text-sm text-slate-700 mt-2">Timely rides for hearings, probation check-ins, and mandated appointments.</p></div>
            <div className="rounded-2xl border p-6"><h3 className="font-semibold">Employment & Essentials</h3><p className="text-sm text-slate-700 mt-2">Interviews, ID renewals, medical visits, housing intake, and more.</p></div>
          </div>
        </div>
      </section>

      <section id="how" className="py-16 bg-slate-50">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-10 items-start">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">How it works</h2>
            <ol className="mt-6 grid gap-4 text-sm text-slate-700">
              <li><strong>1. Request</strong> — Book online, call dispatch, or schedule via a partner agency.</li>
              <li><strong>2. Confirm</strong> — Get confirmation with driver ETA and contact details.</li>
              <li><strong>3. Ride</strong> — Courteous, door‑to‑door assistance.</li>
              <li><strong>4. Arrive</strong> — On time to treatment, court, or your essential appointment.</li>
            </ol>
          </div>
          <div className="rounded-2xl border p-6 bg-white">
            <h3 className="font-semibold text-lg">Service Standards</h3>
            <ul className="mt-4 space-y-2 text-sm text-slate-700">
              <li>• Trauma-informed, dignity-first approach</li>
              <li>• Clean, insured vehicles with regular maintenance</li>
              <li>• Driver training on de-escalation and cultural humility</li>
              <li>• Clear policies for no-shows, cancellations, and safety</li>
            </ul>
          </div>
        </div>
      </section>

      <section id="about" className="py-16">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">About Neighborhood Rides</h2>
            <p className="mt-3 text-slate-700 leading-relaxed">
              Founded in St. Paul, MN, Neighborhood Rides Inc. provides purpose-built transportation for individuals in
              treatment and those who are justice-involved. Our mission: remove transportation barriers so people can
              show up for the moments that matter—recovery, accountability, and opportunity.
            </p>
            <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
              <div className="rounded-2xl border p-4"><div className="text-slate-500">Fleet</div><div className="font-semibold">2 vehicles</div></div>
              <div className="rounded-2xl border p-4"><div className="text-slate-500">Hours</div><div className="font-semibold">7 days/week</div></div>
              <div className="rounded-2xl border p-4"><div className="text-slate-500">Coverage</div><div className="font-semibold">Twin Cities Metro</div></div>
            </div>
          </div>
          <div className="rounded-2xl border p-6">
            <h3 className="font-semibold text-lg">Partners & Referrals</h3>
            <ul className="mt-4 space-y-2 text-sm text-slate-700">
              <li>• Treatment centers & sober homes</li>
              <li>• Probation & reentry programs</li>
              <li>• Courts, public defenders & social workers</li>
            </ul>
          </div>
        </div>
      </section>

      <section id="booking" className="py-16 bg-slate-50">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold tracking-tight">Book a Ride</h2>
          <p className="mt-2 text-slate-600">Same-day requests accepted as availability allows. For guaranteed service, schedule at least 24 hours in advance.</p>
          <div className="mt-8 grid md:grid-cols-3 gap-6">
            <div className="md:col-span-2 rounded-2xl border p-6 bg-white">
              <div className="grid md:grid-cols-2 gap-4">
                <input className="border rounded-md p-2" placeholder="Your name" value={name} onChange={e=>setName(e.target.value)} />
                <input className="border rounded-md p-2" placeholder="Phone number" value={phone} onChange={e=>setPhone(e.target.value)} />
              </div>
              <div className="grid md:grid-cols-2 gap-4 mt-4">
                <input className="border rounded-md p-2" placeholder="Pickup address" value={pickup} onChange={e=>setPickup(e.target.value)} />
                <input className="border rounded-md p-2" placeholder="Drop-off address" value={dropoff} onChange={e=>setDropoff(e.target.value)} />
              </div>
              <input className="border rounded-md p-2 mt-4" placeholder="Date & time (e.g., 2025-08-26 9:30 AM)" value={date} onChange={e=>setDate(e.target.value)} />
              <textarea className="border rounded-md p-2 mt-4 w-full" placeholder="Notes (court case #, treatment program, accommodations, etc.)" value={notes} onChange={e=>setNotes(e.target.value)} />
              <div className="flex gap-3 mt-4">
                <button onClick={handleBooking} className="px-5 py-2 rounded-2xl bg-slate-900 text-white">Submit Request</button>
                <a href={`tel:${BUSINESS_PHONE}`} className="underline text-sm">Call instead</a>
              </div>
            </div>
            <div className="rounded-2xl border p-6 bg-white text-sm text-slate-700">
              <div>• Twin Cities metro; extended trips by arrangement.</div>
              <div className="mt-2">• Standard hours: 6am–9pm; after-hours on request.</div>
              <div className="mt-2">• Fares quoted at booking; partner invoicing available.</div>
              <div className="mt-2">• Seatbelts required; zero-tolerance policy for impairment behind the wheel.</div>
            </div>
          </div>
        </div>
      </section>

      <section id="contact" className="py-16">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Get in touch</h2>
            <p className="mt-2 text-slate-600">Partnerships, referrals, and media inquiries are welcome.</p>
            <div className="mt-6 grid gap-2 text-sm">
              <a href={`tel:${BUSINESS_PHONE}`}>{BUSINESS_PHONE}</a>
              <a href="mailto:{DISPATCH_EMAIL}">{DISPATCH_EMAIL}</a>
              <div>St. Paul, Minnesota</div>
            </div>
          </div>
          <div className="rounded-2xl border p-6 bg-white text-sm text-slate-700">
            Missed court dates and treatment sessions can derail progress. Reliable transportation keeps people connected to
            accountability and care—supporting safer communities and better outcomes.
          </div>
        </div>
      </section>

      <footer className="border-t">
        <div className="max-w-6xl mx-auto px-4 py-10 grid sm:grid-cols-3 gap-6 text-sm">
          <div>
            <div className="font-semibold">Neighborhood Rides Inc.</div>
            <p className="text-slate-600 mt-2">Driving Recovery and Achievement One Ride at a Time.</p>
          </div>
          <div>
            <div className="font-semibold">Hours</div>
            <p className="text-slate-600 mt-2">{HOURS_LONG}</p>
          </div>
          <div>
            <div className="font-semibold">Contact</div>
            <p className="text-slate-600 mt-2">{BUSINESS_PHONE} • {DISPATCH_EMAIL}</p>
          </div>
        </div>
        <div className="text-center text-xs text-slate-500 pb-8">© {new Date().getFullYear()} Neighborhood Rides Inc. All rights reserved.</div>
      </footer>
    </main>
  );
}
