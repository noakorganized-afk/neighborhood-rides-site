"use client";
import React from "react";
import { CALENDLY_URL } from "../config";
export default function SchedulePage() {
  return (
    <main className="min-h-screen py-16">
      <div className="max-w-5xl mx-auto px-4">
        <h1 className="text-3xl font-bold tracking-tight">Schedule a Ride</h1>
        <p className="mt-2 text-slate-600">Use the embedded scheduler below. If you prefer, call dispatch.</p>
        <div className="mt-6 rounded-2xl border overflow-hidden">
          <iframe
            title="Ride scheduling"
            src={CALENDLY_URL}
            className="w-full h-[900px]"
            loading="lazy"
          />
        </div>
      </div>
    </main>
  );
}
