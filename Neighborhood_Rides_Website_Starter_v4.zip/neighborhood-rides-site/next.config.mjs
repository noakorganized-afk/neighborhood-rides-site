export default { images: { unoptimized: true } };
